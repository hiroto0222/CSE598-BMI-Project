//
//  BMI_Client_AppApp.swift
//  BMI Client App
//
//  Created by Hiroto Aoyama on 2023/06/25.
//

import SwiftUI

@main
struct BMI_Client: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
